﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnightMovement : MonoBehaviour
{
    public float _xRotation, _yRotation, _rotationSpeed;
    private float _xPrev, _yPrev;
    private Vector3 _mouse, _prevMouse, _xVector, _yVector;
    
    private float _moveSpeed;
    public float _walkSpeed = 1f;
    public float _runSpeed = 5f;

    public float Gravity = -9.81f; //acceleration of gravity
    public float _jumpHeight = 5f;
    private bool _groundedPlayer;
    private Vector3 _velocity;

    //private Transform parent;
    private Camera _fpsCamera;
    private CharacterController _controller; //references Character Controller component

    private Gun _gun;
    private Ray _ray;

    // Start is called before the first frame update
    void Start()
    {
        _gun = gameObject.GetComponent<Gun>();
        _fpsCamera = Camera.main;
        _controller = GetComponent<CharacterController>();
        _ray = new Ray();
        //parent = transform.parent;
        Cursor.lockState = CursorLockMode.Locked;
        _rotationSpeed = 7f;
        _xRotation = _yRotation = 0f;
        _mouse = Vector3.zero;
    }

    // Update is called once per frame
    void Update()
    {
        //_xPrev = _xRotation;
        //_yPrev = _yRotation;
        //_prevMouse = _mouse;

        
        _mouse = _fpsCamera.ScreenToViewportPoint(Input.mousePosition);

        //Vector3 deltaMouse = new Vector3((_mouse - _prevMouse).normalized);

        //if(_mouse.x < _xDeadZone && deltaMouse.x < 0)
        //{

        //}

        //transform.Rotate(-_yRotation, 0, 0);
        //transform.Rotate(0, _xRotation, 0);
        turnPlayer();


        Movement();
    }

    private void Movement()
    {
        _groundedPlayer = _controller.isGrounded;

        if (_groundedPlayer && _velocity.y < 0)
        {
            _velocity.y = 0f;
        }

        Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")); //predefined axes in Unity linked to WASD controlls
        move = transform.TransformDirection(move); //changes direction 



        _velocity.y += Gravity * Time.deltaTime; //setting velocity in the y direction to the acceleration of gravity in relation to our fps (Time.deltaTime)
        _controller.Move(_velocity * Time.deltaTime); //movement based on velocity

        if (move != Vector3.zero && !Input.GetKey(KeyCode.LeftShift))
        {
            Walk();
        }
        else if (move != Vector3.zero && Input.GetKey(KeyCode.LeftShift))
        {
            Run();
        }
        if (Input.GetButtonDown("Jump") && _groundedPlayer)
        {
            Jump();
        }

        _controller.Move(move * Time.deltaTime * _moveSpeed);
    }

    private void Walk()
    {
        _moveSpeed = _walkSpeed; //set my movement to walking speed
    }

    private void Run()
    {
        _moveSpeed = _runSpeed;
    }

    private void Jump()
    {
        _velocity.y += Mathf.Sqrt(-_jumpHeight * Gravity); //change velocity to reflect a jumping behavior
    }

    //private IEnumerator Attack()
    //{
    //    _animator.SetLayerWeight(_animator.GetLayerIndex("Attack Layer"), 1); //attack layer is being accessed in it's entirety-- accesses the avatar mask to only utilize certain parts of the body
    //    _animator.SetTrigger("Attack"); //uses trigger called Atatck

    //    yield return new WaitForSeconds(0.9f); //wait almost a full second...
    //    _animator.SetLayerWeight(_animator.GetLayerIndex("Attack Layer"), 0); //...before disabling the avatar mask, and returning movement to the entire body 
    //}


    private void turnPlayer()
    {
        float InputX = Input.GetAxis("Mouse X");
        float InputY = Input.GetAxis("Mouse Y");
        
        InputX *= _rotationSpeed;
        InputY *= _rotationSpeed;
        _mouse = _fpsCamera.ScreenToViewportPoint(Input.mousePosition);
        float tempX = _mouse.x;
        Debug.Log(tempX);
        //if(tempX > .85f)
        //{
        //    InputX *= 2;
        //}
        _xRotation += InputX;
        _yRotation += InputY;
        _yRotation = Mathf.Clamp(_yRotation, -90f, 90f);
        _controller.transform.rotation = Quaternion.Euler(-_yRotation, _xRotation, 0);
        
        //_controller.transform.Rotate(-_yRotation * Time.deltaTime, 0, 0, Space.Self);
       
        //_controller.transform.rotation = Quaternion.Euler(0, _xRotation, 0);

        //_prevMouse = _fpsCamera.ScreenToWorldPoint(Input.mousePosition);
        
        //float tempY = _mouse.y;
        //float prevTempX = _prevMouse.x;
        //float prevTempY = _prevMouse.y;

        //Debug.Log(prevTempY);

        //if ((tempX) < .1f)
        //{
        //   _controller.transform.Rotate(0, -120f * Time.deltaTime, 0, Space.Self);
        //}
        //else if(tempX > .9f)
        //{
        //    _controller.transform.Rotate(0, 120f * Time.deltaTime, 0, Space.Self);
        //}

        //if(tempY > .85f)
        //{
        //    _controller.transform.Rotate(-120f * Time.deltaTime, 0, 0, Space.Self);
        //}
        //else if(tempY < .15f)
        //{
        //    _controller.transform.Rotate(120f * Time.deltaTime, 0, 0, Space.Self);
        //}
    }
}
