using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Brutes : MonoBehaviour
{
    //Rotation variables
    public float _xRotation;
    public int _rotationCooldown = 10;
    private int _currentCooldown;
    private Quaternion _newRotation;

    //planar movement variables
    private float _moveSpeed;
    public float _walkSpeed = .5f;
    public float _runSpeed = 3.5f;
    private Rigidbody _rigidbody;

    //ray variables
    private Ray _ray;
    private RaycastHit _seenPlayer;

    //Attack variables
    public int _damagePerHit = 20;
    public int _attackCoolDown = 5;
    public float _sightRange = 30f;
    private bool _chargingFlag;

    //Health
    public int _hp = 100;

    void Start()
    {
        _rigidbody = gameObject.GetComponent<Rigidbody>();
        _ray = new Ray(transform.position, transform.forward);
        _moveSpeed = _walkSpeed;
        _currentCooldown = _rotationCooldown;
        _chargingFlag = false;
        _rotatingFlag = false;
    }

    void Update()
    {
        _chargingFlag = Physics.Raycast(transform.position, transform.forward, out _seenPlayer, Mathf.Infinity, 0);

        if (_chargingFlag)
        {
            Charge();
        }
        else
        {
            Wander();
        }
        

        
    }

    void Wander()
    {
        _moveSpeed = _walkSpeed;

        if(!_rotatingFlag)
        {
            if(_currentCooldown == _rotationCooldown)
            {
                _newRotation = Random.rotation;
            }
        }

        //_rigidbody.MovePosition(_seenPlayer.point * Time.deltaTime * _moveSpeed);

        Quaternion deltaRotation = Quaternion.Euler(new Vector 3(0, _xRotation, 0) * Time.deltaTime);
        _rigidbody.MoveRotation(_newRotation * deltaRotation);

        --_currentCooldown;

        if (_currentCooldown == 0)
        {
            _currentCooldown = _rotationCooldown;
            _rotatingFlag = false;
        }
    }

    void Charge()
    {
        _moveSpeed = _runSpeed;

        _rigidbody.MovePosition(_seenPlayer.point * Time.deltaTime * _moveSpeed);

        //Quaternion deltaRotation = Quaternion.Euler(new Vector 3(0, _xRotation, 0) * Time.deltaTime);
        transform.rotation = Quaternion.RotateTowards(transform.rotation, _seenPlayer.transform.rotation, _xRotation);


    }

    void Attack()
    {

    }
}
