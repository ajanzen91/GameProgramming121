﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnightMovement : MonoBehaviour
{
    private float _xDeadZone = 60f;
    private float _yDeadZone = 40f;
    private float _xRotation, _yRotation;
    private float _xPrev, _yPrev;
    private Vector3 _mouse, _prevMouse, _xVector, _yVector;
    
    private float _moveSpeed;
    private float _walkSpeed = 1f;
    private float _runSpeed = 5f;

    private float Gravity = -9.81f; //acceleration of gravity
    private float _jumpHeight = 1.0f;
    private bool _groundedPlayer;
    private Vector3 _velocity;

    //private Transform parent;
    private Camera _fpsCamera;
    private CharacterController _controller; //references Character Controller component

    private Gun _gun;
    private Ray _ray;

    // Start is called before the first frame update
    void Start()
    {
        _gun = gameObject.GetComponent<Gun>();
        _fpsCamera = Camera.main;
        _controller = GetComponent<CharacterController>();
        _ray = new Ray();
        //parent = transform.parent;
        Cursor.lockState = CursorLockMode.Locked;

        _xRotation = _yRotation = 0f;
        _mouse = Vector3.zero;
    }

    // Update is called once per frame
    void Update()
    {
        _xPrev = _xRotation;
        _yPrev = _yRotation;
        _prevMouse = _mouse;

        _xRotation = Input.GetAxis("Mouse X");
        _yRotation = Input.GetAxis("Mouse Y");
        _mouse = _fpsCamera.ScreenToViewportPoint(Input.mousePosition);

        //Vector3 deltaMouse = new Vector3((_mouse - _prevMouse).normalized);

        //if(_mouse.x < _xDeadZone && deltaMouse.x < 0)
        //{

        //}

        transform.Rotate(-_yRotation, 0, 0);
        transform.Rotate(0, _xRotation, 0);
        turnPlayer();


        Movement();
    }

    private void Movement()
    {
        _groundedPlayer = _controller.isGrounded;

        if (_groundedPlayer && _velocity.y < 0)
        {
            _velocity.y = 0f;
        }

        Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")); //predefined axes in Unity linked to WASD controlls
        move = transform.TransformDirection(move); //changes direction 



        _velocity.y += Gravity * Time.deltaTime; //setting velocity in the y direction to the acceleration of gravity in relation to our fps (Time.deltaTime)
        _controller.Move(_velocity * Time.deltaTime); //movement based on velocity

        if (move != Vector3.zero && !Input.GetKey(KeyCode.LeftShift))
        {
            Walk();
        }
        else if (move != Vector3.zero && Input.GetKey(KeyCode.LeftShift))
        {
            Run();
        }
        if (Input.GetButtonDown("Jump") && _groundedPlayer)
        {
            Jump();
        }

        _controller.Move(move * Time.deltaTime * _moveSpeed);
    }

    private void Walk()
    {
        _moveSpeed = _walkSpeed; //set my movement to walking speed
    }

    private void Run()
    {
        _moveSpeed = _runSpeed;
    }

    private void Jump()
    {
        _velocity.y += Mathf.Sqrt(_jumpHeight * -3.0f * Gravity); //change velocity to reflect a jumping behavior
    }

    //private IEnumerator Attack()
    //{
    //    _animator.SetLayerWeight(_animator.GetLayerIndex("Attack Layer"), 1); //attack layer is being accessed in it's entirety-- accesses the avatar mask to only utilize certain parts of the body
    //    _animator.SetTrigger("Attack"); //uses trigger called Atatck

    //    yield return new WaitForSeconds(0.9f); //wait almost a full second...
    //    _animator.SetLayerWeight(_animator.GetLayerIndex("Attack Layer"), 0); //...before disabling the avatar mask, and returning movement to the entire body 
    //}
    

    private void turnPlayer()
    {
        _xVector = _fpsCamera.ScreenToViewportPoint(Input.mousePosition);
        float tempX = _xVector.x;
        
        //Debug.Log(tempX);
        
        if((tempX) < .1f)
        {
            
            _controller.transform.Rotate(0, -180f * Time.deltaTime, 0, Space.Self);
        }
        else if((tempX) > .9f)
        {
            _controller.transform.Rotate(0, 180f * Time.deltaTime, 0, Space.Self);
        }
    }
}
