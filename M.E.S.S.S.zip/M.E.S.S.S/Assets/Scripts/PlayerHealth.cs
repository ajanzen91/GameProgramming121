//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using TMPro;

//public class PlayerHealth : MonoBehaviour
//{
//    public TMP_Text _textScore;
//    public int _health;
//    public GameObject _playerRef;

//    // Start is called before the first frame update
//    void Start()
//    {
//        _textScore.text = _health.ToString();
//    }

//    // Update is called once per frame
//    void Update()
//    {
//        _textScore.text = _health.ToString();
//    }
//}